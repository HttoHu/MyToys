#pragma once

namespace UI
{
    int login();
    void init();
    void create_config();
    void main_page();
}